from .branch_and_bound import BranchAndBound
from search import Graph, Path


class AStar(BranchAndBound):
    def __init__(self):
        super().__init__(True, True)