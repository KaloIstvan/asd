from .graph_search import GraphSearch
from search import Graph, Path
from queue import PriorityQueue

class BestFirst(GraphSearch):
    def search(self, graph: Graph, start: str, goal: str) -> Path:
        raise NotImplementedError()