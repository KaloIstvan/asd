from .graph_search import GraphSearch
from search import Graph, Path


class Beam(GraphSearch):
    def __init__(self, beam_width: int = 2):
        super().__init__()
        self.beam_width = beam_width
    
    def search(self, graph: Graph, start: str, goal: str) -> Path:
        raise NotImplementedError()