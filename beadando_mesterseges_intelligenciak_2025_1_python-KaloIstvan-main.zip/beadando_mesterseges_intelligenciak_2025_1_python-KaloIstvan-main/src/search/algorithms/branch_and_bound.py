from .graph_search import GraphSearch
from search import Graph, Path
from queue import PriorityQueue

class BranchAndBound(GraphSearch):
    def __init__(self, use_extended_list = False, use_heuristic = False):
        super().__init__()
        self.use_extended_list = use_extended_list
        self.use_heuristic = use_heuristic
        
    def search(self, graph: Graph, start: str, goal: str) -> Path:
        raise NotImplementedError()